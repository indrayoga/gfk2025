<?


include_once(APPPATH.'models/master/mmaster.php');
class Mjenispegawai extends mmaster {

	function __construct() {
		
		parent::__construct();
	}



}
	
?>