<?


include_once(APPPATH.'models/master/mmaster.php');
class Mkabupaten extends mmaster {

	function __construct() {
		
		parent::__construct();
	}


}
	
?>