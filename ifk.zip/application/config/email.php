<?php
		$config['protocol'] = 'sendmail';
		$config['mailpath'] = 'C:\\xampp\sendmail\\sendmail.exe';
		//debugvar($config['mailpath']);
		$config['charset'] = 'iso-8859-1';
		$config['smtp_host'] = 'smtp.gmail.com';
		$config['smtp_user'] = 'indra@planet-it.co.id';
		$config['smtp_pass'] = 'indrayoga';
		$config['smtp_port'] = '465';
		$config['mailtype'] = 'html';
		$config['wordwrap'] = TRUE;

?>